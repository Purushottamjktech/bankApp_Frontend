export class Customer {
    CustomerID: number = 0;
    Name: string = '';
    PhoneNumber: string = '';
    Email: string = '';
    DOB: string = '';
    city: string = '';
    state: string = '';
    Country: string = '';
    Address1: string = '';
    Address2: string = '';
    ZipCode: string = '';
    MaritalStatus: string = '';
}

