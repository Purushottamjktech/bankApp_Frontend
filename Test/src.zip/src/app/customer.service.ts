import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Customer } from './customer';


@Injectable({
  providedIn: 'root'
})


export class CustomerService {
  addDetailURL: string;
  getDetailURL: string;
  updateDetailURL: string;
  deleteDetailURL: string;

  constructor(private http: HttpClient) { 
    this.addDetailURL = 'http://localhost:3000/customer/addCustomer';
    this.getDetailURL = 'http://localhost:3000/customer/getAllCustomer';
    this.updateDetailURL = 'http://localhost:3000/customer/updateCustomer';
    this.deleteDetailURL = 'http://localhost:3000/customer/deleteCustomer';
  }

  addCustomer(customer: Customer): Observable<Customer> {
    return this.http.post<Customer>(this.addDetailURL, Customer);
  }

  getAllCustomer(): Observable<Customer[]> {
    return this.http.get<Customer[]>(this.getDetailURL);
  }

  updateCustomer(customer:Customer): Observable<Customer> {
    return this.http.put<Customer>(this.updateDetailURL, Customer);
  }

  deleteCustomer(customer: Customer): Observable<Customer> {
    return this.http.delete<Customer>(this.deleteDetailURL + '/' + Customer);
  }

}



